import streamlit as st 
import pandas as pd
import pydeck as pdk
import numpy as np
import joblib
import tensorflow as tf
from datetime import datetime
from datetime import datetime, timedelta

# --- 1. CONFIGURACIÓN Y ESTILOS (Actualizado con más niveles) ---
st.set_page_config(page_title="Predicción Tráfico Madrid", layout="wide")

st.markdown("""
    <style>
    .stApp { background-color: #0e1117; color: white; }
    .metric-card {
        background-color: #1f2937;
        padding: 20px;
        border-radius: 15px;
        border-left: 8px solid var(--card-color, #3b82f6);
        margin-bottom: 10px;
    }
    .leyenda-box { 
        background-color: rgba(31, 41, 55, 0.9); 
        padding: 15px; border-radius: 10px; border: 1px solid #4b5563;
        font-size: 13px;
    }
    </style>
    """, unsafe_allow_html=True)

# --- 2. CARGA DE RECURSOS ---
@st.cache_resource
def load_resources():
    model = tf.keras.models.load_model('models/traffic_model_pro2.0.keras')
    scaler = joblib.load('models/scaler_pro2.0.pkl')
    df = pd.read_csv('data/datos_procesados2.csv', index_col=0, parse_dates=True)
    columnas = joblib.load('models/columnas_pro2.0.pkl')
    return model, scaler, df, columnas

try:
    model, scaler, df, columnas_input = load_resources()
    fecha_inicio_test = datetime(2025, 7, 13).date() 
    fecha_fin_test = df.index.max().date()
except Exception as e:
    st.error(f"Error cargando archivos: {e}")
    st.stop()

# --- 3. LÓGICA DE NIVELES DE SERVICIO (Basado en Ayto. Madrid) ---
def get_status_config(pred):
    if pred <= 100:
        return {"color": [144, 238, 144], "hex": "#90ee90", "label": "FLUIDO (Muy Bajo)"}
    elif pred <= 500:
        return {"color": [0, 255, 0], "hex": "#00ff00", "label": "FLUIDO"}
    elif pred <= 1000:
        return {"color": [0, 200, 0], "hex": "#00c800", "label": "ESTABLE"}
    elif pred <= 2000:
        return {"color": [0, 100, 0], "hex": "#006400", "label": "LENTO"}
    elif pred <= 3000:
        return {"color": [255, 255, 0], "hex": "#ffff00", "label": "RETENCIONES"}
    elif pred <= 5000:
        return {"color": [255, 140, 0], "hex": "#ff8c00", "label": "CONGESTIÓN"}
    else:
        return {"color": [139, 69, 19], "hex": "#8b4513", "label": "SATURACIÓN"}

# --- 4. LÓGICA IA ---
def predecir(fecha_busqueda):
    try:
        idx = df.index.get_loc(fecha_busqueda)
        ventana = df.iloc[idx - 672 : idx][columnas_input].values
        ventana_scaled = scaler.transform(ventana).reshape(1, 672, len(columnas_input))
        pred_norm = model.predict(ventana_scaled, verbose=0)
        dummy = np.zeros((1, len(columnas_input)))
        dummy[0, 0] = pred_norm[0, 0]
        return int(abs(scaler.inverse_transform(dummy)[0, 0]))
    except: return None

# --- 5. SIDEBAR ---
st.sidebar.title("Control de Tráfico M-30🚦")
fecha_user = st.sidebar.date_input("📅 Fecha de consulta", value=fecha_fin_test, 
                                  min_value=fecha_inicio_test, max_value=fecha_fin_test)
hora_user = st.sidebar.slider("🕒 Hora", 0, 23, 14)
fecha_final = pd.to_datetime(f"{fecha_user} {hora_user}:00:00")

st.sidebar.metric("Precisión Modelo PRO", "97.33%", "+7.50% vs Base")

st.sidebar.markdown("### 📊 Escala de Intensidad")
st.sidebar.markdown("""
<div class="leyenda-box">
    <span style='color:#90ee90'>●</span> 0-100: Muy bajo<br>
    <span style='color:#00ff00'>●</span> 100-500: Fluido<br>
    <span style='color:#00c800'>●</span> 500-1000: Estable<br>
    <span style='color:#006400'>●</span> 1000-2000: Lento<br>
    <span style='color:#ffff00'>●</span> 2000-3000: Retenciones<br>
    <span style='color:#ff8c00'>●</span> 3000-5000: Congestión<br>
    <span style='color:#8b4513'>●</span> >5000: Saturación
</div>
""", unsafe_allow_html=True)

# --- 6. CUERPO PRINCIPAL ---
st.title("🚘 Predicción de Movilidad Urbana")
st.caption(f"Sensor 3488 (M-30 Lateral) | {fecha_final.strftime('%d/%m/%Y - %H:%M h')}")

prediccion = predecir(fecha_final)

if prediccion is not None:
    config = get_status_config(prediccion)
    
    col_map, col_info = st.columns([2.3, 1])
    
    with col_map:
        # Capa de Aura con el nuevo color dinámico
        layer_sensor_aura = pdk.Layer(
            "ScatterplotLayer",
            data=[{"position": [-3.659420389, 40.4217565], "color": config["color"]}],
            get_position="position",
            get_fill_color="color",
            get_radius=80,
            opacity=0.4
        )

        layer_icon = pdk.Layer(
            "TextLayer",
            data=[{"position": [-3.659420389, 40.4217565], "text": "📍"}],
            get_position="position",
            get_text="text",
            get_size=35,
            get_alignment_baseline="'bottom'"
        )

        view_state = pdk.ViewState(latitude=40.42175, longitude=-3.65942, zoom=15.5, pitch=40)
        
        st.pydeck_chart(pdk.Deck(
            map_style='https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json',
            initial_view_state=view_state,
            layers=[layer_sensor_aura, layer_icon],
            tooltip={"text": f"Sensor 3488\nEstado: {config['label']}"}
        ))

    with col_info:
        # Tarjeta métrica con color dinámico en el borde
        st.markdown(f"""
        <div class="metric-card" style="border-left-color: {config['hex']};">
            <p style='margin:0; font-size:14px; opacity:0.8;'>CAUDAL PREDICTIVO</p>
            <h2 style='margin:0;'>{prediccion} <span style='font-size:18px;'>veh/h</span></h2>
            <p style='margin:0; font-size:16px; color:{config['hex']}; font-weight:bold;'>{config['label']}</p>
        </div>
        """, unsafe_allow_html=True)
        
          # --- NUEVA GRÁFICA DE TENDENCIA ---
        st.write("---")
        st.markdown("### 📈 Tendencia Próximas 4h")
        
        proximas_preds = []
        for i in range(1, 5):
            f_next = fecha_final + timedelta(hours=i)
            p = predecir(f_next)
            if p: proximas_preds.append({"Hora": f_next.strftime("%H:00"), "Vehículos": p})
        
        if proximas_preds:
            df_trend = pd.DataFrame(proximas_preds)
            st.line_chart(df_trend.set_index("Hora"), height=180)
else:
    st.error("Fecha fuera de rango.")